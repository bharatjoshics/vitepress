Vue.createApp({
  data() {
    return { 
      value: '',
      goals: [],
    };
  },
  methods: {
    saveGoals(){
      if(this.value.length>0){
        this.goals.push({task: this.value, complete: false});
      }
      this.value=''
    },
    completeGoal(index){
      //this.goals.splice(idx,1);
      this.goals[index].complete = true;
    }
  }
}).mount('#user-goals');
