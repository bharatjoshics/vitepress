<template>
    <li>
        <h2>{{ id }} {{ isFav ? '(Favorite)' : ''}}</h2>
        <button @click="toggleFav">Change Favorite</button>
        <button @click="toggleDetails">{{ detailsAreVisible ? 'Hide' : 'Show' }} Details</button>
        <ul v-if="detailsAreVisible">
            <li><strong>Name:</strong> {{ name }}</li>
            <li><strong>Phone:</strong> {{ phoneNumber }}</li>
            <li><strong>Email:</strong> {{ emailAddress }}</li>
        </ul>
    </li>    
</template>

<script>
    export default {
        props: ['id','name', 'phoneNumber', 'emailAddress','isFav'],
        data(){
            return {
                detailsAreVisible: false,
            };
        },
        methods: {
            toggleDetails() {
                this.detailsAreVisible = !this.detailsAreVisible;
            }, 
            toggleFav(){
                this.$emit('toggle-fav', this.id);
            }
        }
    };
</script>