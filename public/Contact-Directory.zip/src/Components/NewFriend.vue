<template>
    <form @submit.prevent="submitData">
        <div>
            <label>Id</label>
            <input type="text" v-model="addId"/>
        </div>
        <div>
            <label>Name</label>
            <input type="text" v-model="addName"/>
        </div>
        <div>
            <label>Phone</label>
            <input type="tel" v-model="addPhone"/>
        </div>
        <div>
            <label>Email</label>
            <input type="email" v-model="addEmail"/>
        </div>
        <div>
            <button>Add Friend</button>
        </div>
    </form>
</template>

<script>
export default {
    emits: ['add-friend'],
    data(){
        return {
            addId: '',
            addName: '',
            addPhone:'',
            addEmail: ''
        };
    },
    methods: {
        submitData(){
            this.$emit('add-friend', this.addId, this.addName, this.addPhone, this.addEmail);
            this.addId='';
            this.addName='';
            this.addPhone='';
            this.addEmail='';
        }
    }
};
</script>