Vue.createApp({
  data() {
    return { 
      value: '',
      goals: [],
    
    };
  },
  methods: {
    saveGoals(){
      if(this.value.length>0){
        this.goals.push(this.value);
      }
      this.value=''
    },
    completeGoal(idx){
      this.goals.splice(idx,1);
    }
  }
}).mount('#user-goals');
