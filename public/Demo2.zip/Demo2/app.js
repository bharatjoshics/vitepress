const app = Vue.createApp({
  data() {
    return {
      counter: 0,
    };
  },
  methods: {
    add() {
      return this.counter+=1
    },
    remove() {
      if(this.counter>0){
        return this.counter -= 1
      }
    }
  }
});

app.mount('#events');
